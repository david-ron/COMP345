/*
 * google.cpp
 *
 *  Created on: Oct 18, 2017
 *      Author: David
 */

#include "indexer.h"
#include "document.h"
#include "query_result.h"
#include "stopword.h"
#include "tokenizer.h"

int main()
{
	document *doc1 = new document("file1.txt");
	vector<string> dummy;
	dummy = doc1->content();
	document *doc0 = new document("file2.txt");
	indexer idx2 = indexer();
	indexer idx = indexer();
	idx>>*doc0;
	idx>>*doc1;
	int i = 1;
	document *dictionary = new document();
	document *doc = new document();
	*doc = idx[i];
	dictionary->toCreateDictionary(*doc);
	i = 0;
	*doc = idx[i];
	dictionary->toCreateDictionary(*doc);
	dictionary->sorting();
	dictionary->duplicateRemove();
	idx.dftfFinder(*dictionary);
	idx.normalize();
	cout<<"stopwords printing"<<endl;
	document *docStop = new document ("stop.txt");
	indexer idxStop = indexer();
	idxStop >> *docStop;
	int j = 1;
	document *stopDict = new document ();
	stopDict->compare(*dictionary);
	stopDict->sorting();
	stopDict->duplicateRemove();
	idx.dftfFinder(*stopDict);
	idx.query("josh");
}
