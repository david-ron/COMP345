/*
 * query_result.h
 *
 *  Created on: Oct 18, 2017
 *      Author: David
 */

#ifndef QUERY_RESULT_H_
#define QUERY_RESULT_H_

#include "document.h"

class query_result{
private:
	document doc;
	int score;
    vector<int> tf;
    //unique words
    vector<int> uw;
    vector<double> tf_idf_weights;
public:
	query_result();
	query_result(document & docc,int scoree);
	void info();
	void uwtfFinder(vector<string> str, document & dictionary);
};

#endif /* QUERY_RESULT_H_ */
