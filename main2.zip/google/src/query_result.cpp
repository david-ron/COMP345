/*
 * query_result.cpp
 *
 *  Created on: Oct 18, 2017
 *      Author: David
 */
#include "query_result.h"

/*!
 *
 */
void query_result::info()
{
	cout<<score<<" "<< doc.name();
}
/*!
 *default constructor
 */
query_result::query_result(){
	score = 0;
}
/*!
 *
 * @param docc
 * @param scoree
 */
query_result::query_result(document & docc,int scoree)
{
	score = scoree;
	doc = docc;
}

void query_result::uwtfFinder(vector<string> str, document & dictionary)
{
	int count=0;
	vector<int> empty;
	vector<string> diction = dictionary.content();
	vector<string> temp;
	for(unsigned int j = 0; j<str.size();++j){
			for (unsigned int i = 0; i < diction.size(); ++i) {

				if (str[j] == diction[i])
				{
					++count;
				}
			}

				tf.push_back(count);
				count = 0;
		}
}


